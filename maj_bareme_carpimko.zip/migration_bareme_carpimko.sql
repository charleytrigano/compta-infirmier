-- ============================================================================
-- BAREME CARPIMKO : même principe que le barème URSSAF (bareme_urssaf) : une
-- table de référence partagée entre tous les infirmiers, avec pour chaque
-- année les plafonds/taux du Régime de Base (Tranche 1 / Tranche 2), du
-- Régime Complémentaire et de l'Invalidité-Décès (RID). Modifiable depuis
-- l'écran "⚙️ Barème CARPIMKO" de l'application, sans intervention technique.
--
-- À exécuter dans Supabase : "SQL Editor" > "New query" > coller tout le
-- contenu ci-dessous > "Run". Fait UNE SEULE FOIS.
-- ============================================================================

create table if not exists bareme_carpimko (
  annee                     int primary key,
  pass                      numeric not null,   -- Plafond Annuel de la Sécurité Sociale de l'année
  taux_base_tranche1        numeric not null,    -- % : taux Régime de Base sur la Tranche 1 (jusqu'à 1 PASS)
  plafond_base_tranche1     numeric not null,    -- € : plafond de la Tranche 1 (généralement 1 PASS)
  taux_base_tranche2        numeric not null,    -- % : taux Régime de Base sur la Tranche 2 (jusqu'à 5 PASS)
  plafond_base_tranche2     numeric not null,    -- € : plafond de la Tranche 2 (généralement 5 PASS)
  forfait_complementaire    numeric not null,    -- € : partie forfaitaire du Régime Complémentaire
  taux_complementaire       numeric not null,    -- % : taux appliqué à la part de revenu au-delà du seuil
  seuil_complementaire      numeric not null,    -- € : revenu à partir duquel le taux proportionnel s'applique
  plafond_excedent_complementaire numeric not null, -- € : montant maximum de revenu (au-delà du seuil) soumis au taux
  rid_montant               numeric not null,    -- € : forfait annuel Invalidité-Décès (RID)
  forfait_debut_activite_pct numeric not null,   -- % du PASS retenu comme assiette forfaitaire (1ère / 2ème année)
  notes                     text                 -- zone libre (ex : "à vérifier avec la Carpimko")
);

-- Table volontairement PARTAGÉE (les cotisations CARPIMKO sont les mêmes pour
-- tous les infirmiers, ce n'est pas une donnée personnelle) mais protégée par
-- une règle explicite pour tout utilisateur connecté (lecture + écriture) :
alter table bareme_carpimko enable row level security;

create policy "bareme_carpimko_lecture_ecriture_partagee"
  on bareme_carpimko for all
  to authenticated
  using (true)
  with check (true);

-- Valeurs de départ. 2024/2025 reprennent l'ancien barème codé en dur.
-- 2026 tient compte de la réforme CARPIMKO (taux Tranche 1 relevé à 8,73 %,
-- Régime Complémentaire devenu intégralement proportionnel avec un plancher
-- et un plafond au lieu d'un forfait fixe, RID relevé à 1 022 €) : à VÉRIFIER
-- avec votre relevé CARPIMKO officiel ou votre comptable avant de payer.
insert into bareme_carpimko (
  annee, pass, taux_base_tranche1, plafond_base_tranche1,
  taux_base_tranche2, plafond_base_tranche2,
  forfait_complementaire, taux_complementaire, seuil_complementaire, plafond_excedent_complementaire,
  rid_montant, forfait_debut_activite_pct, notes
) values
  (2024, 46368, 8.23, 46368, 1.87, 231840, 1976.00, 3.04, 39412.80, 231840, 880.00, 19.00, 'Valeurs reprises de l''ancien barème codé en dur.'),
  (2025, 47100, 8.23, 47100, 1.87, 235500, 1976.00, 3.04, 40035.00, 235500, 880.00, 19.00, 'Valeurs reprises de l''ancien barème codé en dur.'),
  (2026, 48060, 8.73, 48060, 1.87, 240300, 2090.61, 8.70, 24030.00, 120150, 1022.00, 19.00, 'ESTIMATION suite à la réforme CARPIMKO 2026 (Tranche 1 à 8,73 %, Régime Complémentaire devenu proportionnel avec plancher/plafond au lieu d''un forfait fixe, RID à 1 022 €) : à VÉRIFIER avec votre relevé CARPIMKO officiel ou votre comptable avant de vous en servir pour payer.')
on conflict (annee) do nothing;
